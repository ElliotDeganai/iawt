<script>
export default {
    props: {
        align: {
            type: String,
            default: 'right',
        },
        width: {
            type: String,
            default: '48',
        },
        contentClasses: {
            type: String,
            default: 'py-1 bg-white',
        },
    },
    data() {
        return {
            open: false,
        };
    },
    computed: {
        widthClass() {
            return { 48: 'w-48' }[this.width.toString()] || 'w-48';
        },
        alignmentClasses() {
            if (this.align === 'left') return 'ltr:origin-top-left rtl:origin-top-right start-0';
            if (this.align === 'top') return 'origin-top';
            return 'ltr:origin-top-right rtl:origin-top-left end-0';
        },
    },
    created() {
        this.closeHandler = (e) => {
            if (!this.$el.contains(e.target)) {
                this.open = false;
            }
        };
    },
    mounted() {
        document.addEventListener('click', this.closeHandler);
    },
    beforeUnmount() {
        document.removeEventListener('click', this.closeHandler);
    },
};
</script>

<template>
    <div class="relative">
        <div @click="open = !open">
            <slot name="trigger" />
        </div>

        <div v-show="open" class="fixed inset-0 z-40" @click="open = false" />

        <transition
            enter-active-class="transition ease-out duration-200"
            enter-from-class="transform opacity-0 scale-95"
            enter-to-class="transform opacity-100 scale-100"
            leave-active-class="transition ease-in duration-75"
            leave-from-class="transform opacity-100 scale-100"
            leave-to-class="transform opacity-0 scale-95"
        >
            <div
                v-show="open"
                class="absolute z-50 mt-2 rounded-md shadow-lg"
                :class="[widthClass, alignmentClasses]"
                @click="open = false"
            >
                <div class="rounded-md ring-1 ring-black ring-opacity-5" :class="contentClasses">
                    <slot name="content" />
                </div>
            </div>
        </transition>
    </div>
</template>
