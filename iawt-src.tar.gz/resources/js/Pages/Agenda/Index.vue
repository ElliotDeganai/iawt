<script>
import PublicLayout from '@/Layouts/PublicLayout.vue';
import { Head } from '@inertiajs/vue3';
export default {
    components: { PublicLayout, Head },
    props: { events: Array, categories: { type: Array, default: () => [] } },
    data() { return { activeFilter: null }; },
    computed: {
        filteredEvents() { return this.activeFilter ? this.events.filter(e => e.event_category_id === this.activeFilter) : this.events; },
    },
    methods: {
        toggleFilter(id) { this.activeFilter = this.activeFilter === id ? null : id; },
        formatDate(d) { return new Date(d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }); },
        catColor(e) { return e.category?.color || '#7A1F2B'; },
    },
};
</script>
<template>
    <Head title="Agenda — InAfrikaWeTrust" />
    <PublicLayout>
        <section class="bg-primary-800 px-4 py-10 sm:px-6 lg:px-8"><div class="mx-auto max-w-5xl"><p class="mb-1 text-[10px] font-medium uppercase tracking-widest text-gold-400">Agenda</p><h1 class="font-serif text-3xl font-normal text-white">Les événements à venir</h1></div></section>
        <div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
            <div v-if="categories.length" class="mb-6">
                <p class="mb-2 text-[10px] font-semibold uppercase tracking-widest text-gray-400">Filtrer par catégorie</p>
                <div class="flex flex-wrap gap-2">
                    <button type="button" class="inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs transition" :class="!activeFilter?'border-primary-600 bg-primary-50 text-primary-700 font-medium':'border-gray-200 text-gray-500'" @click="activeFilter=null">Tous</button>
                    <button v-for="cat in categories" :key="cat.id" type="button" class="inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs transition" :class="activeFilter===cat.id?'font-medium':'border-gray-200 text-gray-600'" :style="activeFilter===cat.id?{borderColor:cat.color,backgroundColor:cat.color+'15',color:cat.color}:{}" @click="toggleFilter(cat.id)"><span class="h-2.5 w-2.5 rounded-full shrink-0" :style="{background:cat.color}"></span>{{ cat.name }}</button>
                </div>
            </div>
            <div v-if="filteredEvents.length" class="space-y-4">
                <div v-for="event in filteredEvents" :key="event.id" class="flex gap-4 rounded-xl border border-gray-100 bg-white p-4 sm:p-5 overflow-hidden">
                    <img v-if="event.image" :src="`/storage/${event.image}`" class="h-24 w-24 shrink-0 rounded-lg object-cover sm:h-28 sm:w-28" alt="" />
                    <div class="flex-1 min-w-0">
                        <div class="flex flex-wrap items-center gap-2 mb-1">
                            <span v-if="event.category" class="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium" :style="{background:catColor(event)+'18',color:catColor(event)}"><span class="h-1.5 w-1.5 rounded-full" :style="{background:catColor(event)}"></span>{{ event.category.name }}</span>
                            <span v-if="event.is_featured" class="rounded-full bg-gold-50 px-2 py-0.5 text-[10px] font-medium text-gold-700">En vedette</span>
                        </div>
                        <h3 class="text-sm font-medium text-gray-900 sm:text-base">{{ event.title }}</h3>
                        <p class="mt-0.5 text-xs text-gray-500">{{ formatDate(event.date) }}<span v-if="event.time"> · {{ event.time }}</span></p>
                        <p v-if="event.description" class="mt-2 text-xs leading-relaxed text-gray-600 line-clamp-2">{{ event.description }}</p>
                        <a v-if="event.url" :href="event.url" target="_blank" rel="noopener" class="mt-2 inline-flex items-center gap-1 text-xs font-medium text-primary-600 hover:underline">En savoir plus →</a>
                    </div>
                    <div class="hidden sm:block w-1 shrink-0 rounded-full" :style="{background:catColor(event)}"></div>
                </div>
            </div>
            <p v-else class="py-12 text-center text-sm text-gray-400">Aucun événement à venir pour le moment.</p>
        </div>
    </PublicLayout>
</template>
