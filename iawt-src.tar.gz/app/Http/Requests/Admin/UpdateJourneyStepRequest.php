<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateJourneyStepRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->hasPermission('home_content.manage');
    }

    public function rules(): array
    {
        return [
            'icon'             => ['required', 'string', 'max:50'],
            'label'            => ['required', 'string', 'max:191'],
            'description'      => ['nullable', 'string'],
            'image'            => ['nullable', 'file', 'mimes:png,jpg,jpeg,webp'],
            'remove_image'     => ['boolean'],
            'position'         => ['required', 'integer', 'min:0'],
        ];
    }
}
