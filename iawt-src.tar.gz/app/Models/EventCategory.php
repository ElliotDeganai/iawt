<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EventCategory extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'slug', 'color', 'sort_order'];

    public function events()
    {
        return $this->hasMany(Event::class);
    }
}
